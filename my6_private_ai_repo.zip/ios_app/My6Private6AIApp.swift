import SwiftUI
@main
struct My6Private6AIApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}
